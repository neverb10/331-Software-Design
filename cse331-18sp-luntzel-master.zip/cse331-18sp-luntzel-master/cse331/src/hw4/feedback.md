ck

**CSE 331 18sp**

**Name:** Jon Frederick Luntzel (luntzel)

**Graded By:** Cody Kesting (cse331-staff@cs.washington.edu)

### Score: 95/122
---

**Problem 0 - Polynomial Arithmetic:** 14/14

- a. 4/4
- b. 6/6 (you don't need to add in the remainder at the end)
- c. 4/4

**Problem 1 - Ratnum:** 9/9

- a. 2/3 -1: equals also needs to be changed
- b. 3/3
- c. 3/3

**Problem 2 - RatTerm:** 28/30

15/15 scripts
7/7 style
- a. 2/2
- b. 2/3 -1: toString also needs to change
- c. 2/3 -1: you also need to explain which invariant is preferable

**Problem 3 - RatPoly :** 29/45

14/30 scripts
15/15 style -0: it's not necessary to copy the list term by term in your duplicate() method. Instead, you should just use a copy-constructor such as "new ArrayList<>(list)" for duplicating

**Problem 4 - RatPolyStack:** 11/20

7/15 scripts
4/5 style -1: Stack is a subclass of Vector, so you can use the get(int index) method to directly access specific elements (instead of needing to remove, then re-add elements)

**Problem 5 - CalculatorFrame:** 2/2

**Turnin:** 2/2


