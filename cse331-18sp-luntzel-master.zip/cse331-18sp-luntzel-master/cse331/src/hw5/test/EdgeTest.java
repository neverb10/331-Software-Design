package hw5.test;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import hw5.Edge;
import hw5.Node;

public class EdgeTest {
	
	private String label;
	private Node<String> origin;
	private Node<String> destination;
	private Edge<String, String> e;
	private final int TIMEOUT = 2000;

	@Before
	public void setUp() throws Exception {
		label = "AB";
	    origin = new Node<String>("A");
		destination = new Node<String>("B");
		e = new Edge<String, String>(origin, destination, label);
	}
	
	@Test(timeout = TIMEOUT)
	public void testGetLabel() {
		assertEquals(e.getLabel(), label);
	}
	
	@Test(timeout = TIMEOUT)
	public void testgetStart() {
		assertEquals(e.getStart(), origin);
	}
	
	@Test(timeout = TIMEOUT)
	public void testgetEnd() {
		assertEquals(e.getEnd(), destination);
	}
	
	@Test(timeout = TIMEOUT)
	public void testEquals() {
		assertTrue(e.equals(new Edge<String, String>(new Node<String>("A"), new Node<String>("B"), "AB")));
		assertFalse(e.equals(new Edge<String, String>(destination, origin, "AB")));
	}
}
