package hw5.test;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import hw5.Node;

public class NodeTest {

	private String value;
	private Node<String> node2;
	private Node<String> node1;
	private final int TIMEOUT = 2000;

	@Before
	public void setUp() throws Exception {
		value = "A";
		node1 = new Node<String>(value);
		node2 = new Node<String>(value);
	}
	
	@Test(timeout = TIMEOUT)
	public void testGetValue() {
		assertEquals(node1.getValue(), value);
		assertEquals(node2.getValue(), value);
	}
	
	@Test(timeout = TIMEOUT)
	public void testHashCode() {
		assertEquals(node1.hashCode(), node2.hashCode());
	}
	
	@Test(timeout = TIMEOUT)
	public void testEquals() {
		assertTrue(node1.equals(node2));
	}
}
