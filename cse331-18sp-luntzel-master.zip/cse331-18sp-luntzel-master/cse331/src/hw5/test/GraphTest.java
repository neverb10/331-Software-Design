package hw5.test;

import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import hw5.*;

public class GraphTest {
	private Graph<String, String> g;
	private HashMap<Node<String>, HashSet<Edge<String, String>>> adjL;
	private HashMap<Node<String>, HashSet<Edge<String, String>>> check;
	private HashSet<Edge<String, String>> edges;
	private String label;
	private Node<String> node1;
	private Node<String> node2;
	private Edge<String, String> e;
	private final int TIMEOUT = 2000;
	
	@Before
	public void setUp() throws Exception {
		label = "AB";
		node1 = new Node<String>("A");
		node2 = new Node<String>("B");
		e = new Edge<String, String>(node1, node2, label);
		adjL = new HashMap<Node<String>, HashSet<Edge<String, String>>>();
		check = new HashMap<Node<String>, HashSet<Edge<String, String>>>();
		edges = new HashSet<Edge<String, String>>();
		g = new Graph<String, String>(adjL);
	}
	
	@Test(timeout = TIMEOUT)
	public void testPlaceNode() {
		check.put(node1, edges);
		g.placeNode(node1);
		assertEquals(check, g.adjacencyList);

	}
	
	@Test(timeout = TIMEOUT)
	public void testPlaceEdge() {
		check.put(node2, edges);
		HashSet<Edge<String, String>> edges2 = new HashSet<Edge<String, String>>();
		edges2.add(e);
		check.put(node1, edges2);
		g.placeNode(node1);
		g.placeNode(node2);
		g.placeEdge(e);
		assertEquals(check, g.adjacencyList);
	}
	
	@Test(timeout = TIMEOUT)
	public void testDuplicates() {
		g.placeNode(node2);
		g.placeNode(node2);
		g.adjacencyList.remove(node2);
		assertFalse(g.adjacencyList.containsKey(node2));
	}
	
	@Test(timeout = TIMEOUT)
	public void testListNodes() {
		g.placeNode(node1);
		Set<String> nodes = g.ListNodes();
		assertTrue(nodes.contains(node1.getValue()));
	}
	
	@Test(timeout = TIMEOUT)
	public void testListEdges() {
		g.placeNode(node1);
		g.placeNode(node2);
		g.placeEdge(e);
		HashSet<Edge<String, String>> edges = g.ListEdges(node1);
		assertTrue(edges.contains(e));
	}
}
