### HW9 Feedback

**CSE 331 18sp**

**Name:** Jon Frederick Luntzel (luntzel)

**Graded By:** Jason Qiu (cse331-staff@cs.washington.edu)

### Score: 50/50
---

- comment

