### HW8 Feedback

**CSE 331 18sp**

**Name:** Jon Frederick Luntzel (luntzel)

**Graded By:** <Jake Sippy> (cse331-staff@cs.washington.edu)

### Score: 41/72
---
**Problem 0 - MVC:** 4/5

- You seem to understand the difference between the model view and controller, but your classification of which parts of your code belong to each is not very clear (-1)

**Problems 1-3: Campus Paths:** 29/55

- Correctness: 9/35
  - 13 out of 20 staff tests failed (-2 each)
  - The paths you find are not the shortest. Likely, either the parsing of the data file is incorrect, or your implementation of dijkstras.
- Style: 20/20
  - Javadoc @param tags should be in the form: "@param <name> <description>" (-0)
  - @effects should only be used to reference how the data structures being used are changed. The description of the class should go above all of the tags in javadoc (-0)
  - Cardinal directions should be computed in the model and represented by enums. (-0)

**Problem 4 - Testing:** 8/10

- Missing tests for common cases from among these: unknown options, unknown buildings, displaying the menu, displaying the buildings, finding paths, quitting the program. (-2)

**Turnin:** 0/2

- Your most recent commit was not tagged with hw8-final, an earlier one was, but I graded the later one since it was passing more tests.

