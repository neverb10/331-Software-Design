package hw8.test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import hw5.Edge;
import hw5.Graph;
import hw5.Node;
import hw8.CampusParser;
import hw8.CampusParser.MalformedDataException;
import hw8.CampusCoord;

public class CampusParserTest {
    private static final int TIMEOUT = 3000;
	private Graph<Double, CampusCoord> cPaths;
	private Map<String, CampusCoord> bCoords;
	private Map<String, String> bNames; 
    private HashMap<Node<CampusCoord>, HashSet<Edge<Double, CampusCoord>>> graphField;

    @Before
    public void setUp() {
    	graphField = 
    			new HashMap<Node<CampusCoord>, HashSet<Edge<Double, CampusCoord>>>();
    	
    	bCoords = new HashMap<String, CampusCoord>();
		bNames = new HashMap<String, String>();
		cPaths = new Graph<Double, CampusCoord>(graphField);
    }
    
    @Test(timeout = TIMEOUT)
    public void parseBuildingsEmpty() throws MalformedDataException {
        CampusParser.parseBuildings("src/hw8/data/empty_buildings.dat", bNames, bCoords);
        assertEquals(bNames, new HashMap<String, String>());
    }
    
    @Test(timeout = TIMEOUT)
    public void parsePathsEmpty() throws Exception {
    	CampusParser.parsePaths("src/hw8/data/empty_paths.dat", cPaths);
        assertEquals(graphField, new HashMap<Node<CampusCoord>, HashSet<Edge<Double, CampusCoord>>>());
    }
    
    /*
	@Test(expected = IllegalArgumentException.class)
    public void untabbedTest() throws Exception {
        CampusParser.parsePaths("src/hw8/data/untabbed_paths.dat", cPaths); 
    }
    */
    
    @Test(timeout = TIMEOUT)
    public void parseBuildingsSmall() throws MalformedDataException {
    	CampusParser.parseBuildings("src/hw8/data/small_buildings.dat", bNames, bCoords);
    	Map<String, String> duplicateN = new HashMap<String, String>();
    	duplicateN.put("AAA", "Albus Hall");
    	duplicateN.put("BBB",  "Borkis Center");
    	duplicateN.put("CCC", "Crockpot Library");
    	Map<String, CampusCoord> duplicateC = new HashMap<String, CampusCoord>();
    	duplicateC.put("AAA", new CampusCoord(0.0, 0.0));
    	duplicateC.put("BBB", new CampusCoord(3.0, 0.0));
    	duplicateC.put("CCC", new CampusCoord(0.0, 4.0));
    	assertEquals(duplicateC, bCoords);
    	assertEquals(duplicateN, bNames);
    }
    
    @Test(timeout = TIMEOUT)
	public void parsePathsSmall() throws Exception {
    	CampusParser.parsePaths("src/hw8/data/small_paths.dat", cPaths);
    	HashMap<Node<CampusCoord>, HashSet<Edge<Double, CampusCoord>>> duplicateField = 
				new HashMap<Node<CampusCoord>, HashSet<Edge<Double, CampusCoord>>>();
		Graph<Double, CampusCoord> duplicateGraph = new Graph<Double, CampusCoord>(duplicateField);
		Node<CampusCoord> c1 = new Node<CampusCoord>(new CampusCoord(0.0,0.0));
		Node<CampusCoord> c2 = new Node<CampusCoord>(new CampusCoord(3.0,0.0));
		Node<CampusCoord> c3 = new Node<CampusCoord>(new CampusCoord(0.0,4.0));
		duplicateGraph.placeNode(c1);
		duplicateGraph.placeNode(c2);
		duplicateGraph.placeNode(c3);
		duplicateGraph.placeEdge(new Edge<Double, CampusCoord>(c1, c2, 3.0));
		duplicateGraph.placeEdge(new Edge<Double, CampusCoord>(c2, c1, 3.0));
		duplicateGraph.placeEdge(new Edge<Double, CampusCoord>(c2, c3, 5.0));
		duplicateGraph.placeEdge(new Edge<Double, CampusCoord>(c3, c2, 5.0));
    	assertEquals(graphField, duplicateField);
	}

}