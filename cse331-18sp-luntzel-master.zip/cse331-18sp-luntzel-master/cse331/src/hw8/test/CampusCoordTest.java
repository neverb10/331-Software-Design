package hw8.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import hw8.*;

public class CampusCoordTest {
	public static final int TIMEOUT = 2000;
	public CampusCoord c1;
	public CampusCoord c2;
	public CampusCoord c3;
	public CampusCoord c4;
	public CampusCoord c5;

	@Before
	public void setUp() throws Exception {
		c1 = new CampusCoord(0.0, 0.0);
		c2 = new CampusCoord(10.0, 10.0);
		c3 = new CampusCoord(30.0, 30.0);
		c4 = new CampusCoord(0.0, 0.0);
		c5 = new CampusCoord(10.0, 20.0);
	}

	@Test(timeout = TIMEOUT)
	public void getYCheck() {
		assertTrue(c1.getY() < 1.0);
		assertTrue(c1.getY() > -1.0);
		assertTrue(c2.getY() < 11.0);
		assertTrue(c2.getY() > 9.0);
	}

	@Test(timeout = TIMEOUT)
	public void getXCheck() {
		assertTrue(c2.getX() < 11.0);
		assertTrue(c2.getX() > 9.0);
		assertTrue(c3.getX() < 31.0);
		assertTrue(c3.getX() > 29.0);
	}

	@Test(timeout = TIMEOUT)
	public void equalsTest() {
		assertTrue(c4.equals(c1));
		assertFalse(c4.equals(c2));
	}

	@Test(timeout = TIMEOUT)
	public void getDirectionTest() {
		//System.out.println(c2.getDirection(c5) + "\n" + c1.getDirection(c2));
		assertEquals(c3.getDirection(c2), "NW");
		assertEquals(c1.getDirection(c2), "SE");
		assertEquals(c2.getDirection(c5), "S");
	}

	@Test(timeout = TIMEOUT)
	public void hashCodeTest() {
		assertEquals(c1.hashCode(),(c1.hashCode()));
		assertFalse(c1.hashCode() == c2.hashCode());
		assertFalse(c2.hashCode() == c3.hashCode());
	}

	@Test(timeout = TIMEOUT)
	public void compareToTest() {
		assertTrue(c1.equals(c1));
		assertFalse(c1.equals(c2));
		assertFalse(c2.equals(c3));

	}
}