package hw8.test;

import java.util.HashMap;
import java.util.List;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import hw5.Edge;
import hw8.CampusCoord;
import hw8.CampusModel;

public class CampusModelTest {
	private static final int TIMEOUT = 3000;
	private CampusModel cEmpty;
	private CampusModel cSmall;

	@Before
	public void setUp() throws Exception {
		cEmpty = new CampusModel("src/hw8/data/empty_buildings.dat", "src/hw8/data/empty_paths.dat");
		cSmall = new CampusModel("src/hw8/data/small_buildings.dat", "src/hw8/data/small_paths.dat");
	}

	@Test(timeout = TIMEOUT)
	public void constructbuildingsEmpty() throws Exception {
		assertEquals(new HashMap<String, String>(), cEmpty.abbCoords());
	}

	@Test(expected = IllegalArgumentException.class)
	public void constructPathsEmpty() throws Exception {
		cEmpty.findCoordinates("BBB");
	}

	@Test(timeout = TIMEOUT)
	public void findCoordinatesSmall() throws Exception {
		cSmall.findCoordinates("BBB");
	}

	@Test(timeout = TIMEOUT)
	public void findBestPathSmall() throws Exception {
		CampusCoord a = new CampusCoord(0.0, 0.0);
		CampusCoord b = new CampusCoord(0.0, 4.0);
		List<Edge<Double, CampusCoord>> path = cSmall.findBestPath(a, b);
		double length = 0;
		for (Edge<Double, CampusCoord> e : path) {
			length += e.getLabel();
		}
		// 0.0 + 3.0 + 5.0 = 8.0
		assertTrue(length < 8.1);
		assertTrue(length > 7.9);
	}
}