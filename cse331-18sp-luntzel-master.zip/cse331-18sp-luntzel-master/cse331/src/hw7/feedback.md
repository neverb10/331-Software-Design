### HW7 Feedback

**CSE 331 18sp**

**Name:** Jon Frederick Luntzel (luntzel)

**Graded By:** Hongtao Huang (cse331-staff@cs.washington.edu)

### Score: 35/77
---
**Problem 1 - Making Your Graph Generic:** 15/30

- Correctness: 9/20
  - Failing multiple hw5 and hw6 specification tests. Your hw5 and hw6 tests should still pass after you made your graph generic.
- Style: 6/10
  - Node type should also be generic (-2)
  - type parameters not documented in Javadoc. (-2)

**Problem 2 - Weighted Graphs and Least-Cost Paths:** 8/30

- Correctness: 0/20
  - Failing all tests. Either test driver was not implemented correctly or serious flaws in your graph. Please try to run your own specification test before submission to try to debug.
- Style: 8/10
  - Missing Javadoc for loadGraph (-2)

**Problem 3 - Testing:** 10/15

- Does not cover an adequate domain of inputs, including common cases for the path-finding algorithm as well as edge cases (nodes missing, no path, etc.). (-5)

**Turnin:** 2/2
