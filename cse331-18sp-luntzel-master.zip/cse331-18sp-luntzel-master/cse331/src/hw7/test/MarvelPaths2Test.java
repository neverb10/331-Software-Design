package hw7.test;

import static org.junit.Assert.*;

import hw5.Edge;
import hw5.Graph;
import hw5.Node;
import hw7.MarvelPaths2;

import org.junit.Before;
import org.junit.Test;

public class MarvelPaths2Test {
	private static final int TIMEOUT = 2000;
	private Graph<Double, String> g;
	
	@Before
	public void setUp() throws Exception {
		//build graph from the tiny data set
		g = MarvelPaths2.loadGraph("src/hw7/data/staffSuperheroes.tsv");
	}
	
	
	@Test(timeout = TIMEOUT)
	public void nodeTest() throws Exception {
		assertEquals(g.ListNodes().toString(), "[Ernst-the-Bicycling-Wizard, "
				+ "Grossman-the-Youngest-of-them-all,"
				+ " Notkin-of-the-Superhuman-Beard, Perkins-the-Magical-Singing-Instructor]");
	}
	
	@Test(timeout = TIMEOUT)
	public void edgeTest() throws Exception {
		Node<String> n = new Node<String>("Ernst-the-Bicycling-Wizard");
		String edges = "";
		for (Edge<Double, String> e : g.ListEdges(n)) {
			edges += e.getEnd().getValue() + " ";
		}
		assertEquals(edges, "Grossman-the-Youngest-of-them-all Notkin-of-the-Superhuman-Beard"
				+ " Notkin-of-the-Superhuman-Beard Perkins-the-Magical-Singing-Instructor ");
	}

	@Test(expected = IllegalArgumentException.class)
	public void loadNullGraph() throws Exception {
		MarvelPaths2.loadGraph(null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void dijPathBadStart() throws Exception {
		MarvelPaths2.findPath(g, "a", "Ernst-the-Bicycling-Wizard");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void dijPathNullGraph() throws Exception {
		MarvelPaths2.findPath(null, "Grossman-the-Youngest-of-them-all Notkin-of-the-Superhuman-Beard",
				"Ernst-the-Bicycling-Wizard");
	}
}

