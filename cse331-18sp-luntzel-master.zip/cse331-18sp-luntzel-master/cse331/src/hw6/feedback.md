### HW6 Feedback

**CSE 331 18sp**

**Name:** Jon Frederick Luntzel (luntzel)

**Graded By:** Hongtao Huang (cse331-staff@cs.washington.edu)

### Score: 25/77
---
**Problems 1 & 2: Pathfinding Implementation:** 10/60

- Correctness: 0/50
  - Not passing any test due to HW6TestDriver missing LoadGraph command
- Style: 10/10
  - Good job!

**Problem 3 - Testing:** 12/12

  - Good job!

**Problem 4 - Command Line Interface :** 1/3

- Some sort of main program, but doesn't really work or major errors (-2)

**Turnin:** 2/2
