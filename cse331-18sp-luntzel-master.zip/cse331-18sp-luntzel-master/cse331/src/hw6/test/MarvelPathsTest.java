package hw6.test;

import static org.junit.Assert.*;

import hw5.*;
import hw6.MarvelPaths;
import org.junit.Before;
import org.junit.Test;

public class MarvelPathsTest {

	private static final int TIMEOUT = 2000;
	private Graph<String, String> g;

	@Before
	public void setUp() throws Exception {
		// build graph from the tiny data set
		g = MarvelPaths.loadGraph("src/hw6/data/staffSuperheroes.tsv");
	}
	
	@Test(timeout = TIMEOUT)
	public void nodeTest() throws Exception {
		assertEquals(g.ListNodes().toString(), "[Ernst-the-Bicycling-Wizard, "
				+ "Grossman-the-Youngest-of-them-all,"
				+ " Notkin-of-the-Superhuman-Beard, Perkins-the-Magical-Singing-Instructor]");
	}
	
	@Test(timeout = TIMEOUT)
	public void edgeTest() throws Exception {
		Node<String> n = new Node<String>("Ernst-the-Bicycling-Wizard");
		String edges = "";
		for (Edge<String, String> e : g.ListEdges(n)) {
			edges += e.getEnd().getValue() + " ";
		}
		assertEquals(edges, "Grossman-the-Youngest-of-them-all Notkin-of-the-Superhuman-Beard"
				+ " Notkin-of-the-Superhuman-Beard Perkins-the-Magical-Singing-Instructor ");
	}
	
	@Test(timeout = TIMEOUT)
	public void pathCheck() throws Exception {
		Edge<String, String> e = new Edge<String, String>(new Node<String>("Ernst-the-Bicycling-Wizard"),
				new Node<String>("Grossman-the-Youngest-of-them-all"), "CSE331");
		assertEquals(MarvelPaths.findPath(g, "Ernst-the-Bicycling-Wizard", "Grossman-the-Youngest-of-them-all").get(0), e); 
	}

	@Test(expected = IllegalArgumentException.class)
	public void loadNullGraph() throws Exception {
		MarvelPaths.loadGraph(null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	//should throw illegalArgumentException for null graph
	public void nullGraphBFS() {
		MarvelPaths.findPath(null, "Ernst-the-Bicycling-Wizard", "Grossman-the-Youngest-of-them-all");
	}
	
	@Test(expected = IllegalArgumentException.class)
	//should throw illegalArgumentException
	public void falsePath() {
		MarvelPaths.findPath(g, "GG", "NO_RE");
	}
}
