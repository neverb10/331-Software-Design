package hw6.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.*;

import hw5.*;
import hw6.MarvelPaths;

/**
 * This class implements a testing driver which reads test scripts from files
 * for testing Graph, the Marvel parser, and your BFS algorithm.
 **/
public class HW6TestDriver {
	public static void main(String args[]) {
		try {
			if (args.length > 1) {
				printUsage();
				return;
			}

			HW6TestDriver td;

			if (args.length == 0) {
				td = new HW6TestDriver(new InputStreamReader(System.in), new OutputStreamWriter(System.out));
			} else {

				String fileName = args[0];
				File tests = new File(fileName);

				if (tests.exists() || tests.canRead()) {
					td = new HW6TestDriver(new FileReader(tests), new OutputStreamWriter(System.out));
				} else {
					System.err.println("Cannot read from " + tests.toString());
					printUsage();
					return;
				}
			}

			td.runTests();

		} catch (IOException e) {
			System.err.println(e.toString());
			e.printStackTrace(System.err);
		}
	}

	protected static void printUsage() {
		System.err.println("Usage:");
		System.err.println("to read from a file: java hw5.test.HW5TestDriver <name of input script>");
		System.err.println("to read from standard in: java hw5.test.HW5TestDriver");
	}

	/** String -> Graph: maps the names of graphs to the actual graph **/
	// TODO for the student: Parameterize the next line correctly.
	private final Map<String, Graph<String, String>> graphs = new HashMap<String, Graph<String, String>>();
	private final PrintWriter output;
	private final BufferedReader input;

	/**
	 * @requires r != null && w != null
	 *
	 * @effects Creates a new HW5TestDriver which reads command from <tt>r</tt> and
	 *          writes results to <tt>w</tt>.
	 **/
	public HW6TestDriver(Reader r, Writer w) {
		input = new BufferedReader(r);
		output = new PrintWriter(w);
	}

	/**
	 * @effects Executes the commands read from the input and writes results to the
	 *          output
	 * @throws IOException
	 *             if the input or output sources encounter an IOException
	 **/
	public void runTests() throws IOException {
		String inputLine;
		while ((inputLine = input.readLine()) != null) {
			if ((inputLine.trim().length() == 0) || (inputLine.charAt(0) == '#')) {
				// echo blank and comment lines
				output.println(inputLine);
			} else {
				// separate the input line on white space
				StringTokenizer st = new StringTokenizer(inputLine);
				if (st.hasMoreTokens()) {
					String command = st.nextToken();

					List<String> arguments = new ArrayList<String>();
					while (st.hasMoreTokens()) {
						arguments.add(st.nextToken());
					}

					executeCommand(command, arguments);
				}
			}
			output.flush();
		}
	}

	private void executeCommand(String command, List<String> arguments) {
		try {
			if (command.equals("CreateGraph")) {
				createGraph(arguments);
			} else if (command.equals("LoadGraph")) {
				loadGraph(arguments);
			} else if (command.equals("FindPath")) {
				findPath(arguments);
			} else if (command.equals("AddNode")) {
				addNode(arguments);
			} else if (command.equals("AddEdge")) {
				addEdge(arguments);
			} else if (command.equals("ListNodes")) {
				listNodes(arguments);
			} else if (command.equals("ListChildren")) {
				listChildren(arguments);
			} else {
				output.println("Unrecognized command: " + command);
			}
		} catch (Exception e) {
			output.println("Exception: " + e.toString());
		}
	}

	private void createGraph(List<String> arguments) {
		if (arguments.size() != 1) {
			throw new CommandException("Bad arguments to CreateGraph: " + arguments);
		}

		String graphName = arguments.get(0);
		createGraph(graphName);
	}

	private void createGraph(String graphName) {
		graphs.put(graphName, new Graph<String, String>(new HashMap<Node<String>, HashSet<Edge<String, String>>>()));
		output.println("created graph " + graphName);
	}

	private void addNode(List<String> arguments) {
		if (arguments.size() != 2) {
			throw new CommandException("Bad arguments to addNode: " + arguments);
		}

		String graphName = arguments.get(0);
		String nodeName = arguments.get(1);

		addNode(graphName, nodeName);
	}

	private void addNode(String graphName, String nodeName) {
		Node<String> node = new Node<String>(nodeName);
		Graph<String, String> g = graphs.get(graphName);
		g.placeNode(node);
		output.println("added node " + nodeName + " to " + graphName);
	}

	//the problem w/ addEdge is that it does not give any output in the testDriver
	private void addEdge(List<String> arguments) {
		if (arguments.size() != 4) {
			throw new CommandException("Bad arguments to addEdge: " + arguments);
		}

		String graphName = arguments.get(0);
		String parentName = arguments.get(1);
		String childName = arguments.get(2);
		String edgeLabel = arguments.get(3);

		addEdge(graphName, parentName, childName, edgeLabel);
	}

	private void addEdge(String graphName, String parentName, String childName, String edgeLabel) {
		Graph<String, String> g = graphs.get(graphName);
		Edge<String, String> e = new Edge<String, String>(new Node<String>(parentName), new Node<String>(childName), edgeLabel);
		g.placeEdge(e);
		output.println("added edge " + edgeLabel + " from " + parentName + " to " + childName +
				" in " + graphName);
	}

	private void listNodes(List<String> arguments) {
		if (arguments.size() != 1) {
			throw new CommandException("Bad arguments to listNodes: " + arguments);
		}

		String graphName = arguments.get(0);
		listNodes(graphName);
	}

	private void listNodes(String graphName) {
		Graph<String, String> g = graphs.get(graphName);
		String outputText = graphName + " contains:";
		Set<String> nodeList = g.ListNodes();
		Set<String> orderedNodes = new TreeSet<String>(nodeList);
		for (String node : orderedNodes) {
			outputText += " " + node;
		}
		output.println(outputText.toString());
	}

	private void listChildren(List<String> arguments) {
		if (arguments.size() != 2) {
			throw new CommandException("Bad arguments to listChildren: " + arguments);
		}

		String graphName = arguments.get(0);
		String parentName = arguments.get(1);
		listChildren(graphName, parentName);
	}

	private void listChildren(String graphName, String parentName) {
		Graph<String, String> g = graphs.get(graphName);
		//List<Edge<String, String>> outgoingEdges = new ArrayList<Edge<String, String>>();
		HashSet<Edge<String, String>> children = g.ListEdges(new Node<String>(parentName));
		
		//use a comparator that first uses the comparator
		//write a comparator to sort outgoingEdges.
		Set<String> orderedChildren = new TreeSet<String>();
		for (Edge<String, String> edges : children) {
			orderedChildren.add(edges.getEnd().getValue() + "(" + edges.getLabel() + ")");
		}
		
		//Iterator<Edge<String, String>> itr = children.iterator();
		//while (itr.hasNext()) {
		//	outgoingEdges.add(itr.next());
		//}
		String outputText = "the children of " + parentName + " in " + graphName + " are:";
		//for (int i = 0; i < outgoingEdges.size(); i++) {
			//outputText += " " + outgoingEdges.get(i).getEnd().getValue() + "(" + outgoingEdges.get(i).getLabel() + ")";
		for (String s : orderedChildren) {
			outputText += " " + s;
		}
		output.println(outputText);
	}	

	//switched input order?
	private void loadGraph(String graph, String file) throws Exception {
		//System.out.print(file);
		String fileName = "src/hw6/data/" + file;
		try {
			graphs.put(graph, MarvelPaths.loadGraph(fileName));
		} catch (java.lang.ClassCastException e) {
			e.printStackTrace();
		}
		output.println("loaded graph " + graph);
	}
	
	private void loadGraph(List<String> arguments) throws Exception {
		if (arguments.size() != 2) {
			throw new CommandException("Bad arguments to loadGraph: " + arguments);
		}

		loadGraph(arguments.get(0), arguments.get(1));
	}

	private void findPath(List<String> arguments) {
		if (arguments.size() != 3) {
			throw new CommandException("Bad arguments to findPath: " + arguments);
		}
		findPath(arguments.get(1), arguments.get(2), arguments.get(0));
	}

	private void findPath(String startLabel, String endLabel, String graphName) {
		Graph<String, String> g = graphs.get(graphName);
		Boolean bool = true;
		String startOutput = startLabel.replace('_', ' ');
		String endOutput = endLabel.replace('_', ' ');
		//possible place of error - comparing new node. changed label to output
		if (!(g.adjacencyList.containsKey(new Node<String>(startOutput)))) {
			output.println("unknown character " + startOutput);
			bool = false;
		}
		if (!(g.adjacencyList.containsKey(new Node<String>(endOutput)))) {
			output.println("unknown character " + endOutput);
			bool = false;
		}
		if (bool) {
			List<Edge<String, String>> path = MarvelPaths.findPath(g, startLabel, endLabel);
			output.println("path from " + startOutput + " to " + endOutput + ":");
			if (path == null) {
				output.println("no path found");
			} else {
				for (Edge<String, String> e : path) {
					String start = e.getStart().getValue().replace('_', ' ');
					String end = e.getEnd().getValue().replace('_', ' ');
					output.println(start + " to "
							+ end + " via " + e.getLabel());
				}
			}
		}
	}
	
	
	/**
	 * This exception results when the input file cannot be parsed properly
	 **/
	static class CommandException extends RuntimeException {

		public CommandException() {
			super();
		}

		public CommandException(String s) {
			super(s);
		}

		public static final long serialVersionUID = 3495;
	}
}
