package hw3.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * ImplementationTest is a simple test suite to test the implementation
 * of each homework.  You do not need to modify this file for Homework 0.
*/
@RunWith(Suite.class)
@SuiteClasses({})
public final class ImplementationTests
{
    //this class is a placeholder for the suite, so it has no members.
}
